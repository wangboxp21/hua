(function() {
	if(location.host.indexOf('.mituo.cn') > 0 ){
		if(location.search.indexOf('pageset=1')>=0) return;
		document.domain = 'mituo.cn';
		var windowMessage=function(callback){
				if (typeof window.addEventListener != 'undefined') {
					window.addEventListener('message', callback, false);
				} else if (typeof window.attachEvent != 'undefined') {
					window.attachEvent('onmessage', callback);
				}
			},
			post_origin=location.host.indexOf('root.')>=0?'http://tests.metinfo.cn':'https://www.metinfo.cn',
			postMessage=function(data) {
				window.parent.postMessage(data || {}, post_origin);
			};
		var is_metinfo=0,
			load_time=0,
			load_time_interval=setInterval(function(){
				load_time+=50;
				var error=0;
				try {
					if(window.parent.M) error=1;
				} catch (err) {
				}
				if(error){
					clearInterval(load_time_interval);
					if(window.parent.location.host=='www.mituo.cn'&&window.parent.location.href.indexOf('&demo=1')>0) return;
					if(window.parent.location.host=='tests.mituo.cn'||window.parent.location.host=='www.mituo.cn') is_metinfo=window.parent.location.origin;
					mituo_handle();
				}else if(load_time>=1000){
					windowMessage(function (e) {
						if(e.origin==post_origin){
							is_metinfo=post_origin;
							window.met_token=e.data.token;
							mituo_handle();
						}
					});
					postMessage({
						action:'source'
					});
					clearInterval(load_time_interval);
				}
			},50);
		function mituo_handle(){
			var error=0;
			try {
				if(self != parent && parent.location.host.indexOf('.mituo.cn')>0 && !is_metinfo) error=1;
			} catch (err) {
			}
			if(error) return;
			// 判断页面是否有固定定位元素
			var is_fixed=1;
			// objs=document.all;
			// for (var i = 0; i < objs.length; i++) {
			//  var style=window.getComputedStyle(objs[i]);
			//  if(style.position=='fixed' && parseInt(style.top)<50){
			//      is_fixed=1;
			//      break;
			//  }
			// }
			if(!is_fixed) document.getElementsByTagName('html')[0].style.paddingTop='50px';
			// 插入css
			var $tool_css=document.createElement("style"),
				tool_css='.met-demo-tool{background:#000!important;z-index: 9999999;}.met-demo-tool-load{line-height:50px;}';
			if(is_fixed){// 有固定定位元素则导航最小化
				tool_css+='.met-demo-tool.tool-min{left: -100% !important;-webkit-transform: translate(125px,0);-ms-transform: translate(125px,0);-o-transform: translate(125px,0);transform: translate(125px,0);}@media (max-width:479px){.met-demo-tool.tool-min{-webkit-transform: translate(113px,0);-ms-transform: translate(113px,0);-o-transform: translate(113px,0);transform: translate(113px,0);}}';
			}
			$tool_css.innerHTML=tool_css;
			document.head.appendChild($tool_css);
			// 插入演示工具
			$demo_tool=document.createElement("div");
			$demo_tool.setAttribute('class','met-demo-tool h-50 met-fixed met-demo-tool-load w-full transition500 p-x-10 text-xs-center');
			$demo_tool.innerHTML='<span class="white font-size-14">演示工具加载中...</span>';
			document.getElementsByTagName('html')[0].insertBefore($demo_tool,document.body);
			// 演示工具处理
			function demoTool(){
				$demo_tool=$('.met-demo-tool');
				$.ajax({
					url: (location.host=='mb.mituo.cn'?'https://www.mituo.cn':'http://tests.mituo.cn')+'/product/showproduct.php?class1=37&demo=1&ajax=1&skin_name='+MSTR[3]+'&from='+is_metinfo,
					type:'GET',
					dataType:'jsonp',
					success:function(result){
						if(!result.status) return;
						$demo_tool.removeClass('met-demo-tool-load p-x-10 text-xs-right text-xs-center').html(result.html);
					}
				});
			}
			var interval=setInterval(function(){
				if(typeof jQuery != "undefined"){
					demoTool();
					clearInterval(interval);
				}
			},50);
		}
	}
})();